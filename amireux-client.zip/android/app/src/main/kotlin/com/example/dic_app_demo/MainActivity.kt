package com.example.dic_app_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
